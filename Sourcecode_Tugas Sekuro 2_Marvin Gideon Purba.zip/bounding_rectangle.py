import cv2
import numpy as np
# Load the image
image = cv2.imread('frame_0000.png')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
_, thresh = cv2.threshold(gray, 128, 255, cv2.THRESH_BINARY_INV)
# Find contours
contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
# Loop through contours
for contour in contours:
    # Get bounding box
    x, y, w, h = cv2.boundingRect(contour)
    
    # Draw rectangle on the image
    cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)

# Display the result
cv2.imshow('Bounding Rectangles', image)
cv2.waitKey(0)
cv2.destroyAllWindows()





